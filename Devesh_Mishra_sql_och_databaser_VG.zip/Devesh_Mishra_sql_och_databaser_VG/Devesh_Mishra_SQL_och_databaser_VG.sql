use world;
CREATE TABLE animals(
Type_animal VARCHAR(255),
name_animal VARCHAR(255) not null,
country_code CHAR(3),
PRIMARY KEY (name_animal));

Insert into `animals` values ('mammal', 'Lion', 'AFG');
INSERT INTO `animals` VALUES ('fish','salmon','SWE');
INSERT INTO `animals` VALUES ('reptiles','cobra','IND');
INSERT INTO `animals` VALUES ('amphibians','frog','ARG');
INSERT INTO `animals` VALUES ('mammal','cat','FIN');
INSERT INTO `animals` VALUES ('mammal','dog','ESP');
INSERT INTO `animals` VALUES ('mammal','horse','IRE');
INSERT INTO `animals` VALUES ('mammal','goat','IRN');
INSERT INTO `animals` VALUES ('mammal','bear','GRD');
INSERT INTO `animals` VALUES ('fish','tuna','GUL');
INSERT INTO `animals` VALUES ('Reptile','crocodile','GRM');

drop table animals;

select * from animals;

/*Show how many cities each country has that has mammals*/
USE world;
SELECT city.CountryCode, count(city.name) 
FROM 
city
inner join 
animals on city.CountryCode = animals.country_code
Where animals.Type_animal = "mammal"
group by CountryCode
order by count(city.name) DESC;

