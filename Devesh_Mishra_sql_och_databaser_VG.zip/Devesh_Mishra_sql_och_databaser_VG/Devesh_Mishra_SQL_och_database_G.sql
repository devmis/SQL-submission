/*Hur många invånare är det i Stockholm?*/
USE World;
Select Name, Population 
From city
Where Name = 'stockholm'
order by Population;

/*Hur många länder finns det som har ’stan’ i namnet?*/
USE world;
select Name 
From country
Where Name regexp 'stan$'
order by Name;

/*Vilka olika styrelsesformer (government form) finns det och hur många gånger 
förkommer varje? Visa i en tabell.*/
USE world;
Select GovernmentForm, count(GovernmentForm)
From country
group by GovernmentForm;

/*Vilka 10 städer har högst population och i vilket land är de olika städerna? (tips 
använd JOIN)*/
USE world;
SELECT c.Population, c.Name, Country.Code 
FROM 
city c 
left join 
country on c.countrycode = country.code
order by Population DESC
limit 10;